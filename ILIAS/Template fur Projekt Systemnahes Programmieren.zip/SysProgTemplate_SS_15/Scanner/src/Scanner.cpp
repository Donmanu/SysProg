/*
 * Scanner.cpp
 *
 *  Created on: Sep 26, 2012
 *      Author: knad0001
 */

#include "../includes/Scanner.h"
#include "../../Automat/includes/Automat.h"

Scanner::Scanner() {
	// TODO Auto-generated constructor stub
	Automat* automat = new Automat();

}

Scanner::~Scanner() {
	// TODO Auto-generated destructor stub
}
