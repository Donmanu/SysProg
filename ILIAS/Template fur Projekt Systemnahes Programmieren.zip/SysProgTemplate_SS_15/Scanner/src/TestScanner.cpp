#include "../includes/Scanner.h"

int main(int argc, char **argv) {

	Scanner* scanner;

	scanner = new Scanner();

}

