/*
 * Scanner.h
 *
 *  Created on: Sep 26, 2012
 *      Author: knad0001
 */

#ifndef SCANNER_H_
#define SCANNER_H_

class Scanner {
public:
	Scanner();
	virtual ~Scanner();
};

#endif /* SCANNER_H_ */
