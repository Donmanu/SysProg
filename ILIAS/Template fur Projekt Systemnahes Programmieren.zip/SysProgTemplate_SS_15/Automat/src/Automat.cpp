/*
 * Automat.cpp
 *
 */

#include "../includes/Automat.h"


Automat::Automat() {
	// TODO Auto-generated constructor stub

}

Automat::~Automat() {
	// TODO Auto-generated destructor stub
}
