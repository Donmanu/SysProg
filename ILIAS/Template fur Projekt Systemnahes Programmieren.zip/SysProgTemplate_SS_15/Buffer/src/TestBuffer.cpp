#include "../includes/Buffer.h"


int main(int argc, char **argv) {

	Buffer*  buffer;

	buffer = new Buffer();

}
