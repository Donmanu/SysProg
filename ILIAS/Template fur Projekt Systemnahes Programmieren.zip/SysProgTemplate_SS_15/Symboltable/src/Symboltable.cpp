/*
 * Symboltable.cpp
 *
 *  Created on: Sep 26, 2012
 *      Author: knad0001
 */

#include "../includes/Symboltable.h"

Symboltable::Symboltable() {
	// TODO Auto-generated constructor stub

}

Symboltable::~Symboltable() {
	// TODO Auto-generated destructor stub
}
