#include "../includes/Symboltable.h"

int main(int argc, char **argv) {

	Symboltable* symboltable;

	symboltable = new Symboltable();


}
